
import React from 'react';
import { Github, Linkedin, Instagram, Mail } from 'lucide-react';

interface SocialIconsProps {
  className?: string;
  iconSize?: number;
  color?: string;
}

const SocialIcons: React.FC<SocialIconsProps> = ({ 
  className = "",
  iconSize = 24,
  color = "currentColor"
}) => {
  return (
    <div className={`flex items-center space-x-4 ${className}`}>
      <a 
        href="https://github.com" 
        target="_blank" 
        rel="noopener noreferrer"
        className="hover:text-gold transition-colors duration-300"
        aria-label="GitHub"
      >
        <Github size={iconSize} color={color} />
      </a>
      <a 
        href="https://linkedin.com" 
        target="_blank" 
        rel="noopener noreferrer"
        className="hover:text-gold transition-colors duration-300"
        aria-label="LinkedIn"
      >
        <Linkedin size={iconSize} color={color} />
      </a>
      <a 
        href="https://instagram.com" 
        target="_blank" 
        rel="noopener noreferrer"
        className="hover:text-gold transition-colors duration-300"
        aria-label="Instagram"
      >
        <Instagram size={iconSize} color={color} />
      </a>
      <a 
        href="mailto:contact@lensandlogic.com" 
        className="hover:text-gold transition-colors duration-300"
        aria-label="Email"
      >
        <Mail size={iconSize} color={color} />
      </a>
    </div>
  );
};

export default SocialIcons;
