
import React from 'react';
import SocialIcons from './SocialIcons';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-deep py-12 text-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <a href="#hero" className="text-white font-montserrat font-bold text-2xl">
              <span className="text-gold">LENS</span>&<span className="text-teal">LOGIC</span>
            </a>
            <p className="mt-2 text-cream text-sm">
              Blending technical expertise with creative vision
            </p>
          </div>
          
          <div className="flex flex-col items-center md:items-end space-y-4">
            <SocialIcons />
            <p className="text-cream text-sm">
              &copy; {currentYear} Alex Morgan. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
