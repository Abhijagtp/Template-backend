
import React, { useState, useEffect } from 'react';
import SocialIcons from '../SocialIcons';
import { ArrowDown } from 'lucide-react';
import { cn } from '@/lib/utils';

const images = [
  '/placeholder.svg',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=1974',
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&q=80&w=1974'
];

const Hero = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setImageLoaded(false);
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const img = new Image();
    img.src = images[currentImageIndex];
    img.onload = () => setImageLoaded(true);
  }, [currentImageIndex]);

  return (
    <section 
      id="hero" 
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image Carousel */}
      <div className="absolute inset-0 z-0">
        {images.map((src, index) => (
          <div
            key={src}
            className={cn(
              "absolute inset-0 transition-opacity duration-1000",
              currentImageIndex === index && imageLoaded ? "opacity-100" : "opacity-0"
            )}
            style={{
              backgroundImage: `url(${src})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
        ))}
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-deep/70 via-deep/50 to-deep/80 backdrop-blur-sm"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 z-10 text-center">
        <h1 className="animate-fade-in text-white text-4xl md:text-5xl lg:text-7xl font-bold mb-6">
          <span className="block">Alex Morgan</span>
        </h1>
        <div className="overflow-hidden mb-8">
          <h2 className="typewriter text-gold text-xl md:text-2xl lg:text-3xl font-medium inline-block">
            Creative Developer & Photographer
          </h2>
        </div>
        <p className="animate-fade-in text-cream text-lg md:text-xl max-w-2xl mx-auto mb-12 delay-300">
          Blending technical excellence with creative vision to craft immersive digital experiences and capture moments that tell powerful stories.
        </p>
        
        {/* Social Icons and CTA */}
        <div className="flex flex-col items-center space-y-8">
          <SocialIcons className="animate-fade-in delay-500 text-white" />
          
          <a 
            href="#portfolio" 
            className="animate-fade-in delay-700 bg-transparent hover:bg-gold text-gold hover:text-deep border-2 border-gold px-8 py-3 rounded-full font-medium transition-all duration-300 inline-flex items-center"
          >
            Explore My Work
          </a>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <a 
        href="#portfolio" 
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white animate-bounce"
        aria-label="Scroll down"
      >
        <ArrowDown size={32} />
      </a>
    </section>
  );
};

export default Hero;
