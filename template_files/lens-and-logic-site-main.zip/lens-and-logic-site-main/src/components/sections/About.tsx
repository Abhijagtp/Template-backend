
import React, { useEffect, useRef } from 'react';

const About = () => {
  const revealRefs = useRef<HTMLDivElement[]>([]);
  
  useEffect(() => {
    const handleScroll = () => {
      revealRefs.current.forEach((ref) => {
        if (!ref) return;
        
        const top = ref.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (top < windowHeight * 0.85) {
          ref.classList.add('active');
        }
      });
    };
    
    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check on initial load
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const addToRefs = (el: HTMLDivElement) => {
    if (el && !revealRefs.current.includes(el)) {
      revealRefs.current.push(el);
    }
  };

  return (
    <section id="about" className="py-20 bg-cream">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-5/12">
            <div 
              className="relative w-full h-96 md:h-[36rem] rounded-lg overflow-hidden shadow-xl"
              ref={addToRefs}
            >
              <div className="absolute inset-0 bg-deep/30 z-10"></div>
              <div 
                className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1150')] bg-cover bg-center grayscale hover:grayscale-0 transition-all duration-500"
              ></div>
              
              <div className="absolute -bottom-2 -left-2 w-32 h-32 border-4 border-gold z-20"></div>
              <div className="absolute -top-2 -right-2 w-32 h-32 border-4 border-teal z-20"></div>
            </div>
          </div>
          
          <div className="lg:w-7/12">
            <div ref={addToRefs} className="reveal">
              <h2 className="text-deep text-4xl font-bold mb-6">About Me</h2>
              <p className="text-lg mb-6 text-gray-700">
                Hi, I'm Alex Morgan, a passionate developer and photographer based in San Francisco. With over 8 years of experience in web development and 5 years in professional photography, I blend technical expertise with creative vision to create immersive digital experiences and capture compelling visual stories.
              </p>
              <p className="text-lg mb-6 text-gray-700">
                My journey began in software engineering, where I developed a strong foundation in creating efficient, elegant code. Over time, I discovered my passion for photography, which has allowed me to develop a unique perspective that informs both my technical work and creative pursuits.
              </p>
              <p className="text-lg mb-8 text-gray-700">
                I believe in the power of technology and visual storytelling to create meaningful connections and impactful experiences. Whether I'm developing a complex web application or capturing the perfect moment through my lens, my goal is to create work that resonates, inspires, and delivers results.
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="text-deep font-semibold text-xl mb-3">Development Philosophy</h3>
                  <p className="text-gray-700">Clean, efficient code that creates intuitive, user-focused experiences.</p>
                </div>
                <div>
                  <h3 className="text-deep font-semibold text-xl mb-3">Photography Style</h3>
                  <p className="text-gray-700">Capturing authentic moments with dramatic lighting and thoughtful composition.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
