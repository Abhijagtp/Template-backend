
import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { ExternalLink, Code, Image } from 'lucide-react';

type PortfolioItem = {
  id: number;
  title: string;
  category: 'web' | 'photo';
  subcategory: string;
  image: string;
  description: string;
  link?: string;
};

const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    title: "E-Commerce Platform",
    category: "web",
    subcategory: "React",
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=1974",
    description: "A modern e-commerce platform built with React and Node.js",
    link: "https://github.com"
  },
  {
    id: 2,
    title: "Analytics Dashboard",
    category: "web",
    subcategory: "Vue",
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&q=80&w=1974",
    description: "Real-time analytics dashboard with data visualization",
    link: "https://github.com"
  },
  {
    id: 3,
    title: "Mountain Sunset",
    category: "photo",
    subcategory: "Landscape",
    image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=1974",
    description: "Breathtaking sunset over mountain ranges",
  },
  {
    id: 4,
    title: "Mobile App",
    category: "web",
    subcategory: "React Native",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1974",
    description: "Cross-platform mobile application for task management",
    link: "https://github.com"
  },
  {
    id: 5,
    title: "Forest Reflection",
    category: "photo",
    subcategory: "Landscape",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&q=80&w=1974",
    description: "Serene forest lake with perfect reflections",
  },
  {
    id: 6,
    title: "Architecture Study",
    category: "photo",
    subcategory: "Architecture",
    image: "https://images.unsplash.com/photo-1466442929976-97f336a657be?auto=format&fit=crop&q=80&w=1974",
    description: "Geometric patterns in modern architecture",
  },
];

type Filter = 'all' | 'web' | 'photo';

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState<Filter>('all');
  const [filteredItems, setFilteredItems] = useState<PortfolioItem[]>(portfolioItems);
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  useEffect(() => {
    if (activeFilter === 'all') {
      setFilteredItems(portfolioItems);
    } else {
      setFilteredItems(portfolioItems.filter(item => item.category === activeFilter));
    }
  }, [activeFilter]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && selectedItem) {
        setSelectedItem(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedItem]);

  const openLightbox = (item: PortfolioItem) => {
    setSelectedItem(item);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedItem(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <section id="portfolio" className="py-20 bg-deep">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-white text-center mb-4">Portfolio</h2>
        <p className="text-cream text-center mb-12 max-w-2xl mx-auto">
          A selection of my development projects and photography work showcasing my technical skills and creative vision.
        </p>

        {/* Filter Controls */}
        <div className="flex justify-center mb-12">
          <div className="flex space-x-4 bg-deep-dark p-2 rounded-full">
            {['all', 'web', 'photo'].map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter as Filter)}
                className={cn(
                  "py-2 px-6 rounded-full font-medium transition-colors duration-300 text-sm md:text-base",
                  activeFilter === filter 
                    ? "bg-gold text-deep" 
                    : "text-white hover:bg-white/10"
                )}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer transform transition-transform duration-300 hover:scale-105 h-64 md:h-72"
              onClick={() => openLightbox(item)}
            >
              <div 
                className="absolute inset-0 bg-cover bg-center z-0 transition-transform duration-500 group-hover:scale-110"
                style={{ backgroundImage: `url(${item.image})` }}
              ></div>
              
              <div className="absolute inset-0 bg-gradient-to-t from-deep via-deep/40 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
              
              <div className="absolute bottom-0 left-0 right-0 p-6 z-10">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gold font-medium bg-deep/60 px-3 py-1 rounded-full backdrop-blur-sm">
                    {item.subcategory}
                  </span>
                  <div className="flex items-center space-x-1">
                    {item.category === 'web' ? (
                      <Code size={16} className="text-gold" />
                    ) : (
                      <Image size={16} className="text-gold" />
                    )}
                  </div>
                </div>
                <h3 className="text-white text-xl font-semibold mb-1 group-hover:text-gold transition-colors duration-300">{item.title}</h3>
                <p className="text-cream text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedItem && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-deep/90 backdrop-blur-md p-4"
          onClick={closeLightbox}
        >
          <div 
            className="relative max-w-5xl w-full bg-white/10 backdrop-blur-xl rounded-lg overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              className="absolute top-4 right-4 text-white hover:text-gold z-10 bg-deep/50 rounded-full p-2"
              onClick={closeLightbox}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
            
            <div className="md:flex">
              <div className="md:w-2/3">
                <img 
                  src={selectedItem.image} 
                  alt={selectedItem.title} 
                  className="w-full h-auto object-cover md:h-full"
                />
              </div>
              <div className="p-6 md:w-1/3 bg-deep/30">
                <div className="mb-2">
                  <span className="text-xs text-gold font-medium bg-deep/60 px-3 py-1 rounded-full">
                    {selectedItem.subcategory}
                  </span>
                </div>
                <h3 className="text-white text-2xl font-bold mb-3">{selectedItem.title}</h3>
                <p className="text-cream mb-6">{selectedItem.description}</p>
                
                {selectedItem.link && (
                  <a 
                    href={selectedItem.link} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-gold hover:text-white transition-colors duration-300"
                  >
                    <span className="mr-2">View Project</span>
                    <ExternalLink size={16} />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Portfolio;
