
import React, { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { Code, Globe, Server, Database, Image, Camera, Video, Lightbulb } from 'lucide-react';

type Service = {
  icon: React.ReactNode;
  title: string;
  description: string;
  category: 'tech' | 'creative';
};

const services: Service[] = [
  {
    icon: <Code size={28} />,
    title: "Web Development",
    description: "Custom, responsive websites and web applications built with modern frameworks and best practices.",
    category: "tech"
  },
  {
    icon: <Globe size={28} />,
    title: "Frontend Development",
    description: "Engaging user interfaces with React, Vue, or Angular that provide seamless user experiences.",
    category: "tech"
  },
  {
    icon: <Server size={28} />,
    title: "Backend Development",
    description: "Robust server-side solutions using Node.js, Express, and other modern technologies.",
    category: "tech"
  },
  {
    icon: <Database size={28} />,
    title: "Database Design",
    description: "Efficient database architecture and implementation for optimal performance and scalability.",
    category: "tech"
  },
  {
    icon: <Camera size={28} />,
    title: "Photography Sessions",
    description: "Professional photography for portraits, events, products, and more with meticulous attention to detail.",
    category: "creative"
  },
  {
    icon: <Image size={28} />,
    title: "Photo Editing",
    description: "Expert retouching and color grading to enhance and perfect your images.",
    category: "creative"
  },
  {
    icon: <Video size={28} />,
    title: "Visual Storytelling",
    description: "Compelling visual narratives that capture your brand's essence and message.",
    category: "creative"
  },
  {
    icon: <Lightbulb size={28} />,
    title: "Creative Direction",
    description: "Strategic creative guidance for projects that require both technical and artistic vision.",
    category: "creative"
  }
];

const Services = () => {
  const servicesRef = useRef<(HTMLDivElement | null)[]>([]);
  
  useEffect(() => {
    const handleScroll = () => {
      servicesRef.current.forEach((ref, index) => {
        if (ref) {
          const rect = ref.getBoundingClientRect();
          const isVisible = rect.top < window.innerHeight * 0.8;
          
          if (isVisible) {
            setTimeout(() => {
              ref.classList.add('opacity-100', 'translate-y-0');
              ref.classList.remove('opacity-0', 'translate-y-10');
            }, index * 100);
          }
        }
      });
    };
    
    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <section id="services" className="py-20 bg-cream">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-deep text-center mb-4">Services</h2>
        <p className="text-gray-700 text-center mb-16 max-w-2xl mx-auto">
          I offer a range of technical and creative services to help bring your vision to life, whether it's through code or through the lens.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              ref={el => servicesRef.current[index] = el}
              className={cn(
                "service-card bg-white p-8 rounded-lg shadow-lg border-t-4 transition-all duration-500 opacity-0 translate-y-10 transform hover:shadow-xl",
                service.category === 'tech' ? "border-teal" : "border-gold"
              )}
            >
              <div className={cn(
                "icon-wrapper h-14 w-14 flex items-center justify-center rounded-lg mb-6",
                service.category === 'tech' ? "bg-teal/10 text-teal" : "bg-gold/10 text-gold"
              )}>
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-deep mb-3">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
