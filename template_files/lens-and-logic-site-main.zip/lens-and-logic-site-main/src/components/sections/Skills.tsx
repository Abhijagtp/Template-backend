
import React, { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';

type Skill = {
  name: string;
  level: number;
  category: 'tech' | 'creative';
};

const skills: Skill[] = [
  { name: 'JavaScript', level: 90, category: 'tech' },
  { name: 'React', level: 85, category: 'tech' },
  { name: 'TypeScript', level: 80, category: 'tech' },
  { name: 'Node.js', level: 75, category: 'tech' },
  { name: 'CSS/SASS', level: 85, category: 'tech' },
  { name: 'Python', level: 70, category: 'tech' },
  { name: 'HTML5', level: 95, category: 'tech' },
  { name: 'MongoDB', level: 75, category: 'tech' },
  
  { name: 'Lightroom', level: 90, category: 'creative' },
  { name: 'Photoshop', level: 85, category: 'creative' },
  { name: 'Figma', level: 80, category: 'creative' },
  { name: 'Premiere Pro', level: 65, category: 'creative' },
  { name: 'Composition', level: 90, category: 'creative' },
  { name: 'Lighting', level: 85, category: 'creative' },
  { name: 'Color Theory', level: 80, category: 'creative' },
  { name: 'Portrait Photography', level: 85, category: 'creative' },
];

const Skills = () => {
  const [activeCategory, setActiveCategory] = useState<'tech' | 'creative' | 'all'>('all');
  const [visibleSkills, setVisibleSkills] = useState<Skill[]>(skills);
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (activeCategory === 'all') {
      setVisibleSkills(skills);
    } else {
      setVisibleSkills(skills.filter(skill => skill.category === activeCategory));
    }
  }, [activeCategory]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section 
      id="skills" 
      ref={sectionRef}
      className="py-20 bg-gradient-to-b from-deep to-deep/90 text-white"
    >
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-4">Skills & Expertise</h2>
        <p className="text-cream text-center mb-12 max-w-2xl mx-auto">
          My dual skill set in both development and photography allows me to approach projects with a unique technical and creative perspective.
        </p>

        {/* Category Filters */}
        <div className="flex justify-center mb-12">
          <div className="bg-white/5 backdrop-blur-sm p-1 rounded-full">
            {['all', 'tech', 'creative'].map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category as 'tech' | 'creative' | 'all')}
                className={cn(
                  "py-2 px-6 rounded-full transition-all duration-300",
                  activeCategory === category 
                    ? "bg-teal text-white" 
                    : "text-white/80 hover:text-white"
                )}
              >
                {category === 'all' ? 'All Skills' : 
                  category === 'tech' ? 'Technical' : 'Creative'}
              </button>
            ))}
          </div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {visibleSkills.map((skill, index) => (
            <div 
              key={skill.name}
              className={cn(
                "glass-card p-6 transition-all duration-500 transform",
                isVisible 
                  ? "opacity-100 translate-y-0" 
                  : "opacity-0 translate-y-10",
                skill.category === 'tech' ? "border-l-4 border-teal" : "border-l-4 border-gold"
              )}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-semibold text-lg">{skill.name}</h3>
                <span className="text-sm bg-deep/50 rounded-full px-2 py-0.5">
                  {skill.level}%
                </span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2.5">
                <div 
                  className={cn(
                    "h-2.5 rounded-full",
                    skill.category === 'tech' ? "bg-teal" : "bg-gold"
                  )}
                  style={{ 
                    width: isVisible ? `${skill.level}%` : '0%',
                    transition: 'width 1s ease-in-out',
                    transitionDelay: `${index * 100 + 300}ms` 
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
