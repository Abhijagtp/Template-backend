
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import GlassCard from '@/components/GlassCard';
import CounterAnimation from '@/components/CounterAnimation';

gsap.registerPlugin(ScrollTrigger);

const AboutSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const bioRef = useRef<HTMLParagraphElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!sectionRef.current) return;
    
    // Animate section heading
    if (headingRef.current) {
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top bottom-=100',
            toggleActions: 'play none none none',
          },
        }
      );
    }
    
    // Animate bio text
    if (bioRef.current) {
      gsap.fromTo(
        bioRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.2,
          scrollTrigger: {
            trigger: bioRef.current,
            start: 'top bottom-=80',
            toggleActions: 'play none none none',
          },
        }
      );
    }
    
    // Stats animations are handled by the CounterAnimation component
    
    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);
  
  return (
    <section 
      id="about" 
      ref={sectionRef}
      className="py-20 relative"
    >
      <div className="container mx-auto px-4">
        <h2 
          ref={headingRef}
          className="text-center text-white font-orbitron mb-12"
        >
          Who I <span className="text-neon-magenta">Am</span>
        </h2>
        
        <div className="max-w-4xl mx-auto">
          <GlassCard className="p-8 mb-12" animated glowColor="magenta">
            <p 
              ref={bioRef}
              className="text-white/80 text-lg leading-relaxed mb-8"
            >
              I'm a data analyst with a passion for transforming complex datasets into compelling visual narratives. 
              With a background in statistics and computer science, I specialize in finding hidden patterns and 
              communicating insights that drive strategic decisions. My approach combines analytical rigor with 
              creative visualization techniques to make data accessible and actionable for everyone.
            </p>
            
            <p className="text-white/80 text-lg leading-relaxed">
              When I'm not diving into datasets, you can find me exploring new visualization techniques, 
              contributing to open-source data projects, or teaching data literacy to aspiring analysts.
              I believe that effective data storytelling is both an art and a science, requiring technical 
              expertise and creative thinking.
            </p>
          </GlassCard>
          
          <div 
            ref={statsRef}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            <GlassCard className="p-6 text-center" glowColor="cyan">
              <h3 className="text-neon-cyan text-4xl font-orbitron mb-2">
                <CounterAnimation value={50} suffix="+" />
              </h3>
              <p className="text-white/70">Dashboards Created</p>
            </GlassCard>
            
            <GlassCard className="p-6 text-center" glowColor="magenta">
              <h3 className="text-neon-magenta text-4xl font-orbitron mb-2">
                <CounterAnimation value={10} suffix="M+" delay={0.3} />
              </h3>
              <p className="text-white/70">Rows Analyzed</p>
            </GlassCard>
            
            <GlassCard className="p-6 text-center" glowColor="green">
              <h3 className="text-neon-green text-4xl font-orbitron mb-2">
                <CounterAnimation value={25} suffix="+" delay={0.6} />
              </h3>
              <p className="text-white/70">Projects Completed</p>
            </GlassCard>
            
            <GlassCard className="p-6 text-center" glowColor="cyan">
              <h3 className="text-neon-cyan text-4xl font-orbitron mb-2">
                <CounterAnimation value={8} suffix="+" delay={0.9} />
              </h3>
              <p className="text-white/70">Years Experience</p>
            </GlassCard>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
