
import React, { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import GlassCard from '@/components/GlassCard';
import NeonButton from '@/components/NeonButton';
import { Mail, Github, Linkedin, Send } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

gsap.registerPlugin(ScrollTrigger);

const ContactSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  
  const { toast } = useToast();
  
  useEffect(() => {
    if (!sectionRef.current) return;
    
    // Animate section heading
    if (headingRef.current) {
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top bottom-=100',
            toggleActions: 'play none none none',
          },
        }
      );
    }
    
    // Animate form elements
    if (formRef.current) {
      const formElements = formRef.current.querySelectorAll('input, textarea, button');
      
      gsap.fromTo(
        formElements,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          stagger: 0.1,
          duration: 0.6,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: formRef.current,
            start: 'top bottom-=50',
            toggleActions: 'play none none none',
          },
        }
      );
    }
    
    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);
  
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, you would send the form data to a server
    console.log('Form submitted:', formData);
    
    // Show success toast
    toast({
      title: "Message sent successfully!",
      description: "I'll get back to you as soon as possible.",
      variant: "default",
    });
    
    // Reset form
    setFormData({ name: '', email: '', message: '' });
  };
  
  return (
    <section 
      id="contact"
      ref={sectionRef}
      className="py-20 relative"
    >
      <div className="container mx-auto px-4">
        <h2 
          ref={headingRef}
          className="text-center text-white font-orbitron mb-12"
        >
          Let's <span className="text-neon-cyan">Decode</span> Insights
        </h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <GlassCard className="p-6" glowColor="cyan">
                <h3 className="text-xl font-orbitron text-white mb-4">
                  Have a dataset you want to explore?
                </h3>
                
                <form ref={formRef} onSubmit={handleSubmit}>
                  <div className="mb-4">
                    <label 
                      htmlFor="name" 
                      className="block text-white/70 mb-2"
                    >
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/10 border border-white/20 rounded-md px-4 py-2 text-white focus:outline-none focus:border-neon-cyan focus:ring-1 focus:ring-neon-cyan transition-colors"
                    />
                  </div>
                  
                  <div className="mb-4">
                    <label 
                      htmlFor="email" 
                      className="block text-white/70 mb-2"
                    >
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full bg-white/10 border border-white/20 rounded-md px-4 py-2 text-white focus:outline-none focus:border-neon-cyan focus:ring-1 focus:ring-neon-cyan transition-colors"
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label 
                      htmlFor="message" 
                      className="block text-white/70 mb-2"
                    >
                      Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows={4}
                      className="w-full bg-white/10 border border-white/20 rounded-md px-4 py-2 text-white focus:outline-none focus:border-neon-cyan focus:ring-1 focus:ring-neon-cyan transition-colors resize-none"
                    />
                  </div>
                  
                  <div className="text-right">
                    <NeonButton 
                      type="submit" 
                      color="cyan"
                    >
                      <Send size={16} className="mr-2" />
                      Send Message
                    </NeonButton>
                  </div>
                </form>
              </GlassCard>
            </div>
            
            <div>
              <GlassCard className="p-6 h-full flex flex-col" glowColor="magenta">
                <h3 className="text-xl font-orbitron text-white mb-6">
                  Connect with Me
                </h3>
                
                <p className="text-white/70 mb-6">
                  Let's connect and discuss how data can transform your projects and decisions.
                </p>
                
                <div className="space-y-4 mt-auto">
                  <a 
                    href="mailto:alex@datanexus.com" 
                    className="flex items-center text-white hover:text-neon-cyan transition-colors"
                  >
                    <Mail size={20} className="mr-3" />
                    alex@datanexus.com
                  </a>
                  
                  <a 
                    href="https://github.com/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center text-white hover:text-neon-cyan transition-colors"
                  >
                    <Github size={20} className="mr-3" />
                    GitHub
                  </a>
                  
                  <a 
                    href="https://linkedin.com/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center text-white hover:text-neon-cyan transition-colors"
                  >
                    <Linkedin size={20} className="mr-3" />
                    LinkedIn
                  </a>
                </div>
              </GlassCard>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
