
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import TypewriterText from '@/components/TypewriterText';
import NeonButton from '@/components/NeonButton';
import Dashboard from '@/components/Dashboard';

gsap.registerPlugin(ScrollTrigger);

const HeroSection: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);
  const quoteRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!heroRef.current) return;
    
    const tl = gsap.timeline();
    
    // Animate title
    if (titleRef.current) {
      tl.fromTo(
        titleRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }
      );
    }
    
    // Subtitle and quote animations are handled by TypewriterText component
    
    // Animate CTA buttons
    if (ctaRef.current) {
      tl.fromTo(
        ctaRef.current.children,
        { opacity: 0, y: 20 },
        { 
          opacity: 1, 
          y: 0, 
          stagger: 0.2, 
          duration: 0.8, 
          ease: 'power3.out' 
        },
        '-=0.4'
      );
    }
    
    return () => {
      tl.kill();
    };
  }, []);
  
  return (
    <section 
      ref={heroRef}
      id="home"
      className="relative min-h-screen pt-24 pb-12 flex items-center"
    >
      {/* Grid Lines Background */}
      <div className="grid-lines"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="w-full lg:w-1/2 mb-10 lg:mb-0">
            <h1 
              ref={titleRef} 
              className="text-white font-orbitron font-bold mb-4"
            >
              Hi, I'm <span className="text-neon-cyan">Alex Chen</span>
            </h1>
            
            <div 
              ref={subtitleRef}
              className="text-xl md:text-2xl text-white/90 font-orbitron mb-6"
            >
              <TypewriterText 
                text="Data Analyst & Insight Storyteller" 
                delay={1}
              />
            </div>
            
            <div 
              ref={quoteRef}
              className="text-lg md:text-xl text-white/70 mb-8 max-w-lg"
            >
              <TypewriterText 
                text="Transforming raw data into powerful stories that drive decisions and inspire action." 
                delay={2.5}
              />
            </div>
            
            <div ref={ctaRef} className="flex flex-wrap gap-4">
              <NeonButton 
                color="cyan" 
                href="#projects"
                magnetic
              >
                View Projects
              </NeonButton>
              
              <NeonButton 
                color="magenta" 
                href="/resume.pdf"
                magnetic
              >
                Download Resume
              </NeonButton>
            </div>
          </div>
          
          <div className="w-full lg:w-1/2 flex justify-center lg:justify-end">
            <Dashboard />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
