
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import GlassCard from '@/components/GlassCard';
import SkillBar from '@/components/SkillBar';

gsap.registerPlugin(ScrollTrigger);

interface Skill {
  name: string;
  percentage: number;
  category: 'languages' | 'tools' | 'soft';
  color: 'cyan' | 'magenta' | 'green';
}

const SkillsSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  
  const skills: Skill[] = [
    // Languages
    { name: 'Python', percentage: 95, category: 'languages', color: 'cyan' },
    { name: 'SQL', percentage: 90, category: 'languages', color: 'cyan' },
    { name: 'R', percentage: 85, category: 'languages', color: 'cyan' },
    { name: 'JavaScript', percentage: 75, category: 'languages', color: 'cyan' },
    
    // Tools
    { name: 'Tableau', percentage: 92, category: 'tools', color: 'magenta' },
    { name: 'Power BI', percentage: 88, category: 'tools', color: 'magenta' },
    { name: 'Excel', percentage: 95, category: 'tools', color: 'magenta' },
    { name: 'Jupyter', percentage: 90, category: 'tools', color: 'magenta' },
    
    // Soft Skills
    { name: 'Data Storytelling', percentage: 95, category: 'soft', color: 'green' },
    { name: 'Data Visualization', percentage: 92, category: 'soft', color: 'green' },
    { name: 'Statistical Analysis', percentage: 88, category: 'soft', color: 'green' },
    { name: 'Machine Learning', percentage: 82, category: 'soft', color: 'green' },
  ];
  
  useEffect(() => {
    if (!sectionRef.current) return;
    
    // Animate section heading
    if (headingRef.current) {
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top bottom-=100',
            toggleActions: 'play none none none',
          },
        }
      );
    }
    
    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);
  
  return (
    <section 
      id="skills"
      ref={sectionRef}
      className="py-20 relative"
    >
      <div className="container mx-auto px-4">
        <h2 
          ref={headingRef}
          className="text-center text-white font-orbitron mb-12"
        >
          My Data <span className="text-neon-green">Stack</span>
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Languages */}
          <GlassCard className="p-6" animated glowColor="cyan">
            <h3 className="text-2xl font-orbitron text-neon-cyan mb-6 text-center">
              Languages
            </h3>
            
            <div>
              {skills
                .filter(skill => skill.category === 'languages')
                .map(skill => (
                  <SkillBar
                    key={skill.name}
                    name={skill.name}
                    percentage={skill.percentage}
                    color={skill.color}
                  />
                ))
              }
            </div>
          </GlassCard>
          
          {/* Tools */}
          <GlassCard className="p-6" animated glowColor="magenta">
            <h3 className="text-2xl font-orbitron text-neon-magenta mb-6 text-center">
              Tools
            </h3>
            
            <div>
              {skills
                .filter(skill => skill.category === 'tools')
                .map(skill => (
                  <SkillBar
                    key={skill.name}
                    name={skill.name}
                    percentage={skill.percentage}
                    color={skill.color}
                  />
                ))
              }
            </div>
          </GlassCard>
          
          {/* Soft Skills */}
          <GlassCard className="p-6" animated glowColor="green">
            <h3 className="text-2xl font-orbitron text-neon-green mb-6 text-center">
              Expertise
            </h3>
            
            <div>
              {skills
                .filter(skill => skill.category === 'soft')
                .map(skill => (
                  <SkillBar
                    key={skill.name}
                    name={skill.name}
                    percentage={skill.percentage}
                    color={skill.color}
                  />
                ))
              }
            </div>
          </GlassCard>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
