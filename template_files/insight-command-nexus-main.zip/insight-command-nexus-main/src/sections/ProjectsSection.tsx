
import React, { useState, useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import ProjectCard from '@/components/ProjectCard';
import GlassCard from '@/components/GlassCard';
import { X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Project {
  id: number;
  title: string;
  description: string;
  tools: string[];
  image: string;
  fullDescription: string;
  outcomes: string[];
}

const ProjectsSection: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  
  const projects: Project[] = [
    {
      id: 1,
      title: "E-commerce Analytics Dashboard",
      description: "Designed a real-time dashboard tracking key performance metrics for an online retailer.",
      tools: ["Python", "Tableau", "SQL"],
      image: "https://placehold.co/600x400/0D0D0D/00FFFF?text=Dashboard",
      fullDescription: "Created a comprehensive analytics solution that transformed raw e-commerce data into actionable insights. The dashboard provided real-time monitoring of sales, customer behavior, and inventory status across multiple channels.",
      outcomes: [
        "Increased conversion rate by 23% through data-driven UI improvements",
        "Reduced customer acquisition costs by 18% by identifying high-performing marketing channels",
        "Optimized inventory management, reducing stockouts by 30%"
      ]
    },
    {
      id: 2,
      title: "Financial Market Predictor",
      description: "Developed a predictive model to forecast market trends based on historical data.",
      tools: ["R", "Python", "Machine Learning"],
      image: "https://placehold.co/600x400/0D0D0D/FF00F5?text=Finance",
      fullDescription: "Built a sophisticated model that analyzed historical market data, news sentiment, and economic indicators to predict short-term market movements. The system incorporated machine learning algorithms to continuously improve its accuracy.",
      outcomes: [
        "Achieved 72% accuracy in predicting market direction",
        "Implemented automated alerts for significant market shifts",
        "Created interactive visualizations to explain complex patterns to stakeholders"
      ]
    },
    {
      id: 3,
      title: "Healthcare Patient Flow Analysis",
      description: "Optimized hospital operations by analyzing patient journey data and identifying bottlenecks.",
      tools: ["Power BI", "Excel", "Process Mining"],
      image: "https://placehold.co/600x400/0D0D0D/00FF9C?text=Healthcare",
      fullDescription: "Conducted a detailed analysis of patient flow data from admission to discharge, identifying key bottlenecks and inefficiencies in hospital operations. The project involved process mining techniques to map the entire patient journey and quantify delays.",
      outcomes: [
        "Reduced average wait times by 35% in high-traffic departments",
        "Optimized staff scheduling based on predicted patient volumes",
        "Improved patient satisfaction scores by 28% within six months"
      ]
    },
    {
      id: 4,
      title: "Supply Chain Optimization",
      description: "Streamlined the global supply chain through advanced analytics and visualization.",
      tools: ["Python", "Tableau", "Network Analysis"],
      image: "https://placehold.co/600x400/0D0D0D/00FFFF?text=Supply+Chain",
      fullDescription: "Applied advanced analytics to optimize a global supply chain network spanning 12 countries. The project involved building interactive visualizations to model different scenarios and identify optimal routing and inventory strategies.",
      outcomes: [
        "Reduced logistics costs by 12% annually",
        "Decreased delivery times by 22% through route optimization",
        "Created an interactive supply chain digital twin for ongoing optimization"
      ]
    },
    {
      id: 5,
      title: "Customer Segmentation Engine",
      description: "Developed a clustering algorithm to identify distinct customer segments for targeted marketing.",
      tools: ["Python", "Machine Learning", "Jupyter"],
      image: "https://placehold.co/600x400/0D0D0D/FF00F5?text=Segmentation",
      fullDescription: "Built a sophisticated customer segmentation engine using unsupervised learning techniques to identify natural groupings in customer behavior data. The solution incorporated demographic, transactional, and engagement metrics to create comprehensive profiles.",
      outcomes: [
        "Identified 5 distinct high-value customer segments previously unrecognized",
        "Increased marketing ROI by 42% through targeted campaigns",
        "Developed an automated system to update segments as new data arrived"
      ]
    },
    {
      id: 6,
      title: "Social Media Sentiment Analyzer",
      description: "Created a real-time dashboard for monitoring brand sentiment across social platforms.",
      tools: ["Python", "NLP", "React"],
      image: "https://placehold.co/600x400/0D0D0D/00FF9C?text=Social+Media",
      fullDescription: "Engineered a real-time sentiment analysis system that monitored brand mentions across multiple social media platforms. The solution utilized natural language processing to classify sentiment and identify emerging trends or issues.",
      outcomes: [
        "Enabled 85% faster response to potential PR issues",
        "Provided competitive intelligence through sentiment comparison",
        "Created automated alerts for significant sentiment shifts"
      ]
    },
  ];
  
  useEffect(() => {
    if (!sectionRef.current) return;
    
    // Animate section heading
    if (headingRef.current) {
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top bottom-=100',
            toggleActions: 'play none none none',
          },
        }
      );
    }
    
    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);
  
  useEffect(() => {
    if (selectedProject && modalRef.current) {
      gsap.fromTo(
        modalRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.4, ease: 'power3.out' }
      );
      
      // Lock body scroll
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedProject]);
  
  const openProjectModal = (project: Project) => {
    setSelectedProject(project);
  };
  
  const closeProjectModal = () => {
    if (modalRef.current) {
      gsap.to(modalRef.current, {
        opacity: 0,
        y: 20,
        duration: 0.3,
        ease: 'power3.in',
        onComplete: () => setSelectedProject(null),
      });
    }
  };
  
  return (
    <section 
      id="projects"
      ref={sectionRef}
      className="py-20 relative"
    >
      <div className="container mx-auto px-4">
        <h2 
          ref={headingRef}
          className="text-center text-white font-orbitron mb-12"
        >
          Insight <span className="text-neon-cyan">Cases</span> & Dashboards
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              title={project.title}
              description={project.description}
              tools={project.tools}
              image={project.image}
              onClick={() => openProjectModal(project)}
            />
          ))}
        </div>
      </div>
      
      {/* Project Detail Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-cyber-dark/80 backdrop-blur-sm">
          <div 
            ref={modalRef}
            className="w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <GlassCard className="p-6 relative">
              <button
                className="absolute top-4 right-4 text-white hover:text-neon-cyan transition-colors"
                onClick={closeProjectModal}
                aria-label="Close modal"
              >
                <X size={24} />
              </button>
              
              <div className="mb-6">
                <h3 className="text-2xl md:text-3xl font-orbitron mb-2">
                  {selectedProject.title}
                </h3>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedProject.tools.map((tool, index) => (
                    <span 
                      key={index}
                      className="px-2 py-1 text-xs rounded-md bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/30"
                    >
                      {tool}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="relative w-full h-56 md:h-72 mb-6 overflow-hidden rounded-md bg-cyber-dark/50">
                <img 
                  src={selectedProject.image} 
                  alt={selectedProject.title} 
                  className="object-cover w-full h-full"
                />
              </div>
              
              <div className="mb-6">
                <h4 className="text-xl font-orbitron mb-2 text-neon-magenta">
                  Project Overview
                </h4>
                <p className="text-white/80 mb-4">
                  {selectedProject.fullDescription}
                </p>
              </div>
              
              <div>
                <h4 className="text-xl font-orbitron mb-2 text-neon-green">
                  Key Outcomes
                </h4>
                <ul className="list-disc list-inside space-y-2 text-white/80">
                  {selectedProject.outcomes.map((outcome, index) => (
                    <li key={index}>{outcome}</li>
                  ))}
                </ul>
              </div>
            </GlassCard>
          </div>
        </div>
      )}
    </section>
  );
};

export default ProjectsSection;
