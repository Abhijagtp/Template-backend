
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

interface TypewriterTextProps {
  text: string;
  delay?: number;
  className?: string;
}

const TypewriterText: React.FC<TypewriterTextProps> = ({ 
  text, 
  delay = 0, 
  className = ''
}) => {
  const textRef = useRef<HTMLSpanElement>(null);
  
  useEffect(() => {
    if (!textRef.current) return;
    
    const chars = text.split('');
    
    // Clear initial text
    textRef.current.textContent = '';
    
    // Set up GSAP timeline
    const tl = gsap.timeline({ delay });
    
    // Add cursor
    const cursor = document.createElement('span');
    cursor.className = 'inline-block w-[2px] h-[1em] bg-neon-cyan ml-[2px] animate-blink';
    textRef.current.appendChild(cursor);
    
    // Type each character
    chars.forEach((char, index) => {
      tl.add(() => {
        const charSpan = document.createElement('span');
        charSpan.textContent = char;
        charSpan.style.opacity = '0';
        textRef.current?.insertBefore(charSpan, cursor);
        
        gsap.to(charSpan, {
          opacity: 1,
          duration: 0.05,
          ease: 'power1.out'
        });
      }, index * 0.05);
    });
    
    return () => {
      tl.kill();
    };
  }, [text, delay]);
  
  return (
    <span 
      ref={textRef} 
      className={`inline-block ${className}`}
      aria-label={text}
    >
      {text}
    </span>
  );
};

export default TypewriterText;
