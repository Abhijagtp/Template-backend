
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

interface SkillBarProps {
  name: string;
  percentage: number;
  color?: 'cyan' | 'magenta' | 'green';
}

const SkillBar: React.FC<SkillBarProps> = ({
  name,
  percentage,
  color = 'cyan',
}) => {
  const progressRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Map color names to actual color values
  const colorMap = {
    cyan: '#00FFFF',
    magenta: '#FF00F5',
    green: '#00FF9C',
  };
  
  const colorHex = colorMap[color];
  
  useEffect(() => {
    if (!progressRef.current || !containerRef.current) return;
    
    const progress = progressRef.current;
    const container = containerRef.current;
    
    gsap.fromTo(
      progress,
      { width: 0 },
      {
        width: `${percentage}%`,
        duration: 1.5,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: container,
          start: 'top bottom-=100',
          toggleActions: 'play none none none',
        },
      }
    );
  }, [percentage]);
  
  return (
    <div ref={containerRef} className="mb-6">
      <div className="flex justify-between items-center mb-2">
        <span className="text-white font-orbitron">{name}</span>
        <span 
          className="text-sm"
          style={{ color: colorHex }}
        >
          {percentage}%
        </span>
      </div>
      
      <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
        <div
          ref={progressRef}
          className="h-full rounded-full"
          style={{ 
            backgroundColor: colorHex,
            boxShadow: `0 0 10px ${colorHex}`,
            width: '0%', // Initial width, will be animated
          }}
        ></div>
      </div>
    </div>
  );
};

export default SkillBar;
