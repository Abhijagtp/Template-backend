
import React from 'react';
import { ArrowUp } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };
  
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-8 relative">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-white/60">
              &copy; {currentYear} DataNexus. All rights reserved.
            </p>
          </div>
          
          <div className="flex items-center">
            <p className="text-white/60 font-orbitron italic mr-6">
              "Data is the new oil. I refine it."
            </p>
            
            <button
              onClick={scrollToTop}
              className="w-10 h-10 rounded-full bg-white/5 border border-neon-cyan/30 flex items-center justify-center text-neon-cyan hover:bg-neon-cyan/10 transition-colors duration-300 focus:outline-none"
              aria-label="Scroll to top"
            >
              <ArrowUp size={18} />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
