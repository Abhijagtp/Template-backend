
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  glowColor?: 'cyan' | 'magenta' | 'green';
  animated?: boolean;
  tilt?: boolean;
}

const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  glowColor = 'cyan',
  animated = false,
  tilt = false,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  
  // Map color names to actual color values
  const colorMap = {
    cyan: '#00FFFF',
    magenta: '#FF00F5',
    green: '#00FF9C',
  };
  
  const colorHex = colorMap[glowColor];
  
  useEffect(() => {
    if (!cardRef.current || !animated) return;
    
    gsap.fromTo(
      cardRef.current,
      { 
        y: 50, 
        opacity: 0,
      },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: cardRef.current,
          start: 'top bottom-=100',
          toggleActions: 'play none none none',
        },
      }
    );
  }, [animated]);
  
  useEffect(() => {
    if (!cardRef.current || !tilt) return;
    
    const card = cardRef.current;
    
    const handleMouseMove = (e: MouseEvent) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const tiltX = (y - centerY) / 10;
      const tiltY = (centerX - x) / 10;
      
      gsap.to(card, {
        rotationX: tiltX,
        rotationY: tiltY,
        duration: 0.5,
        ease: 'power2.out',
      });
    };
    
    const handleMouseLeave = () => {
      gsap.to(card, {
        rotationX: 0,
        rotationY: 0,
        duration: 0.7,
        ease: 'elastic.out(1, 0.7)',
      });
    };
    
    card.addEventListener('mousemove', handleMouseMove);
    card.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      card.removeEventListener('mousemove', handleMouseMove);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [tilt]);
  
  return (
    <div
      ref={cardRef}
      className={`relative overflow-hidden bg-white/5 backdrop-blur-md border border-white/10 rounded-lg shadow-lg ${className}`}
      style={{
        boxShadow: `0 0 15px rgba(${glowColor === 'cyan' ? '0, 255, 255' : glowColor === 'magenta' ? '255, 0, 245' : '0, 255, 156'}, 0.15)`,
        transform: 'translateZ(0)', // Force GPU acceleration
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-white/0 pointer-events-none" />
      {children}
    </div>
  );
};

export default GlassCard;
