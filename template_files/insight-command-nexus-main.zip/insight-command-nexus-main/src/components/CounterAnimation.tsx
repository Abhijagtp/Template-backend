
import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

interface CounterAnimationProps {
  value: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  delay?: number;
  className?: string;
}

const CounterAnimation: React.FC<CounterAnimationProps> = ({
  value,
  prefix = '',
  suffix = '',
  duration = 2,
  delay = 0.2,
  className = '',
}) => {
  const counterRef = useRef<HTMLSpanElement>(null);
  const [displayValue, setDisplayValue] = useState(0);
  
  useEffect(() => {
    if (!counterRef.current) return;
    
    const counter = counterRef.current;
    let startValue = 0;
    let endValue = value;
    
    const updateCounter = () => {
      setDisplayValue(Math.floor(startValue));
    };
    
    gsap.to(
      {},
      {
        duration,
        delay,
        onUpdate: () => {
          const progress = gsap.getProperty({}, 'progress') as number;
          startValue = progress * endValue;
          updateCounter();
        },
        onComplete: () => {
          setDisplayValue(endValue);
        },
        scrollTrigger: {
          trigger: counter,
          start: 'top bottom-=100',
          toggleActions: 'play none none none',
        },
      }
    );
    
    return () => {
      gsap.killTweensOf({});
    };
  }, [value, duration, delay]);
  
  return (
    <span ref={counterRef} className={className}>
      {prefix}
      {displayValue}
      {suffix}
    </span>
  );
};

export default CounterAnimation;
