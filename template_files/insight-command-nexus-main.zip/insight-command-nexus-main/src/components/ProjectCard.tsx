
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import GlassCard from './GlassCard';

interface ProjectCardProps {
  title: string;
  description: string;
  tools: string[];
  image: string;
  onClick: () => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({
  title,
  description,
  tools,
  image,
  onClick,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!cardRef.current) return;
    
    const card = cardRef.current;
    
    gsap.fromTo(
      card,
      { y: 30, opacity: 0 },
      { 
        y: 0, 
        opacity: 1, 
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: card,
          start: 'top bottom-=100',
          toggleActions: 'play none none none',
        }
      }
    );
  }, []);
  
  return (
    <div ref={cardRef} onClick={onClick} className="cursor-pointer">
      <GlassCard 
        className="h-full p-5 transition-all duration-300 transform hover:scale-[1.02]"
        tilt={true}
        glowColor="cyan"
      >
        <div className="flex flex-col h-full">
          <div className="relative w-full h-40 mb-4 overflow-hidden rounded-md bg-cyber-dark/50">
            <img 
              src={image} 
              alt={title} 
              className="object-cover w-full h-full"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark to-transparent"></div>
          </div>
          
          <h3 className="text-xl font-bold mb-2 text-white">
            {title}
          </h3>
          
          <p className="text-white/70 mb-4 flex-grow">
            {description}
          </p>
          
          <div className="flex flex-wrap gap-2 mt-auto">
            {tools.map((tool, index) => (
              <span 
                key={index}
                className="px-2 py-1 text-xs rounded-md bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/30"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>
      </GlassCard>
    </div>
  );
};

export default ProjectCard;
