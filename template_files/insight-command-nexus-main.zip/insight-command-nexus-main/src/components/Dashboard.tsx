
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const Dashboard: React.FC = () => {
  const dashboardRef = useRef<HTMLDivElement>(null);
  const codeRef = useRef<HTMLDivElement>(null);
  
  const chartData = [
    { name: 'Jan', value: 40 },
    { name: 'Feb', value: 65 },
    { name: 'Mar', value: 55 },
    { name: 'Apr', value: 75 },
    { name: 'May', value: 90 },
    { name: 'Jun', value: 80 },
  ];
  
  useEffect(() => {
    if (!dashboardRef.current) return;
    
    // Animate dashboard entrance
    gsap.fromTo(
      dashboardRef.current,
      { opacity: 0, x: 100 },
      { opacity: 1, x: 0, duration: 1, delay: 0.5, ease: 'power3.out' }
    );
    
    // Animate typing effect for code
    if (codeRef.current) {
      const codeLines = codeRef.current.querySelectorAll('div');
      
      gsap.fromTo(
        codeLines,
        { opacity: 0, x: -10 },
        {
          opacity: 1,
          x: 0,
          stagger: 0.15,
          duration: 0.3,
          delay: 1,
          ease: 'power2.out',
        }
      );
    }
  }, []);
  
  return (
    <div 
      ref={dashboardRef} 
      className="glass-panel relative p-5 w-full max-w-md overflow-hidden"
    >
      {/* KPI Counters */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white/5 p-3 rounded-md">
          <div className="text-xs text-white/60 mb-1">Data Points</div>
          <div className="text-xl text-neon-cyan font-orbitron">1.2M+</div>
        </div>
        <div className="bg-white/5 p-3 rounded-md">
          <div className="text-xs text-white/60 mb-1">Accuracy</div>
          <div className="text-xl text-neon-magenta font-orbitron">99.8%</div>
        </div>
        <div className="bg-white/5 p-3 rounded-md">
          <div className="text-xs text-white/60 mb-1">Models</div>
          <div className="text-xl text-neon-green font-orbitron">12</div>
        </div>
        <div className="bg-white/5 p-3 rounded-md">
          <div className="text-xs text-white/60 mb-1">Insights</div>
          <div className="text-xl text-neon-cyan font-orbitron">156</div>
        </div>
      </div>
      
      {/* Chart */}
      <div className="h-40 mb-6 rounded-md overflow-hidden bg-white/5 p-2">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <XAxis 
              dataKey="name" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: 'rgba(255, 255, 255, 0.6)', fontSize: 10 }} 
            />
            <YAxis 
              hide={true}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1A1A1A', 
                borderColor: '#00FFFF',
                borderRadius: '4px',
                color: 'white'
              }} 
            />
            <Bar 
              dataKey="value" 
              fill="#00FFFF" 
              radius={[4, 4, 0, 0]} 
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      {/* Code Block */}
      <div className="bg-cyber-dark/80 rounded-md p-3 overflow-hidden">
        <div className="text-xs text-white/60 mb-2">data_analyzer.py</div>
        <div 
          ref={codeRef} 
          className="font-mono text-xs space-y-1 overflow-hidden"
        >
          <div className="text-neon-green">import pandas as pd</div>
          <div className="text-white">df = pd.read_csv('data.csv')</div>
          <div className="text-neon-magenta">def analyze_trends(data):</div>
          <div className="text-white">    results = data.groupby('category')</div>
          <div className="text-white">    return results.mean()</div>
          <div className="text-neon-cyan">insights = analyze_trends(df)</div>
        </div>
      </div>
      
      {/* Grid Lines overlay */}
      <div className="absolute inset-0 grid-lines opacity-30"></div>
    </div>
  );
};

export default Dashboard;
