
import React, { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { cn } from '@/lib/utils';

interface NeonButtonProps {
  children: React.ReactNode;
  color?: 'cyan' | 'magenta' | 'green';
  className?: string;
  onClick?: () => void;
  href?: string;
  magnetic?: boolean;
}

const NeonButton: React.FC<NeonButtonProps> = ({
  children,
  color = 'cyan',
  className = '',
  onClick,
  href,
  magnetic = false,
}) => {
  const buttonRef = useRef<HTMLAnchorElement | HTMLButtonElement>(null);
  
  const buttonClasses = cn(
    'neon-button',
    {
      'neon-button-cyan': color === 'cyan',
      'neon-button-magenta': color === 'magenta',
      'neon-button-green': color === 'green',
    },
    className
  );
  
  useEffect(() => {
    if (!buttonRef.current || !magnetic) return;
    
    const button = buttonRef.current;
    const buttonBounds = button.getBoundingClientRect();
    const buttonWidth = buttonBounds.width;
    const buttonHeight = buttonBounds.height;
    const magnetStrength = 0.5;
    
    const handleMouseMove = (e: MouseEvent) => {
      const rect = button.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const deltaX = (x - centerX) * magnetStrength;
      const deltaY = (y - centerY) * magnetStrength;
      
      gsap.to(button, {
        x: deltaX,
        y: deltaY,
        duration: 0.3,
        ease: 'power2.out',
      });
    };
    
    const handleMouseLeave = () => {
      gsap.to(button, {
        x: 0,
        y: 0,
        duration: 0.7,
        ease: 'elastic.out(1, 0.7)',
      });
    };
    
    button.addEventListener('mousemove', handleMouseMove);
    button.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      button.removeEventListener('mousemove', handleMouseMove);
      button.removeEventListener('mouseleave', handleMouseLeave);
      gsap.killTweensOf(button);
    };
  }, [magnetic]);
  
  if (href) {
    return (
      <a
        ref={buttonRef as React.RefObject<HTMLAnchorElement>}
        href={href}
        className={buttonClasses}
        onClick={onClick}
      >
        {children}
      </a>
    );
  }
  
  return (
    <button
      ref={buttonRef as React.RefObject<HTMLButtonElement>}
      className={buttonClasses}
      onClick={onClick}
      type="button"
    >
      {children}
    </button>
  );
};

export default NeonButton;
